package org.example;

import java.util.Random;

public class Main {

  private static String argumentInwidth;
  private static String argumentInHigh;
  private static String argumentInGenerations;
  private static String argumentInSpeed;
  private static String argumentInPoulation;
  private static boolean validGameParameters;

  public static void main(String[] args) {

    parameterSeparation(args);

    printParameters(argumentInPoulation, argumentInwidth, argumentInHigh, argumentInGenerations,
        argumentInSpeed);

    validParameterHWP(argumentInPoulation, argumentInwidth, argumentInHigh, args);

    if (validGameParameters) {

      validInitialState(argumentInPoulation, argumentInwidth);

      int width = Integer.parseInt(argumentInwidth);
      int high = Integer.parseInt(argumentInHigh);
      int generations = validGenerations(argumentInGenerations);
      int speed = Integer.parseInt(argumentInSpeed);
      int rows = 0;
      int columns = 0;
      int[][] gameBoard = new int[high][width];
      String initialPattern = argumentInPoulation;
      char[] patters = initialPattern.toCharArray();

      starGameBoard(rows, columns, gameBoard, patters, width, high);

      int counterGenerations = 0;
      while (counterGenerations < generations) {
        counterGenerations++;

        jumpsLines();

        int[][] newTableGame = new int[high][width];

        for (rows = 0; rows < high; rows++) {
          for (columns = 0; columns < width; columns++) {
            System.out.print(gameBoard[rows][columns]);
          }
          System.out.print('\n');
        }

        for (rows = 0; rows < high; rows++) {
          for (columns = 0; columns < width; columns++) {
            int neighbours = 0;

            for (int i = -1; i <= 1; i++) {
              for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) {
                  continue;
                }

                int row = (rows + i + high) % high;

                int col = (columns + j + width) % width;

                neighbours += gameBoard[row][col];
              }
            }

            if (gameBoard[rows][columns] == 0 && neighbours == 3) {
              newTableGame[rows][columns] = 1;
            } else if (gameBoard[rows][columns] == 1) {
              if (neighbours < 2 || neighbours > 3) {
                newTableGame[rows][columns] = 0;
              } else {
                newTableGame[rows][columns] = 1;
              }
            }
          }
        }

        gameBoard = newTableGame;

        jumpsLines();

        try {
          Thread.sleep(speed);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
      }
      if (counterGenerations == generations) {
        System.out.println("end game");
      }
    }
  }

  public static void jumpsLines() {
    for (int i = 0; i < 2; i++) {
      System.out.println('\n');
    }
  }

  public static void parameterSeparation(String[] parameter) {
    for (String arguments : parameter) {
      if (arguments.equals("rnd") || arguments.equals("RND")) {
        argumentInPoulation = "rnd";
      }
      if (arguments.indexOf('=') == 1) {
        if (arguments.indexOf('h') == 0) {
          argumentInHigh = arguments.substring(2);
        } else if (arguments.indexOf('w') == 0) {
          argumentInwidth = arguments.substring(2);
        } else if (arguments.indexOf('p') == 0) {
          argumentInPoulation = arguments.substring(2);
        } else if (arguments.indexOf('s') == 0) {
          argumentInSpeed = arguments.substring(2);
        } else if (arguments.indexOf('g') == 0) {
          argumentInGenerations = arguments.substring(2);
        }
      }
    }
  }

  public static void validParameterHWP(String stateInitial, String width, String high,
      String[] args) {
    try {
      int counterAuxHigh = 0;
      boolean validHigh = true;
      boolean validWidth = true;
      boolean validNumbersWH = false;
      char[] patters = stateInitial.toCharArray();
      int highInt = Integer.parseInt(high);
      int widthInt = Integer.parseInt(width);
      if (args.length != 5) {
        validGameParameters = false;
      } else {
        for (char c : patters) {
          if (c == '#') {
            counterAuxHigh++;
          }
        }
        if (counterAuxHigh > highInt) {
          validHigh = false;
        }
        String[] patterns_separation = stateInitial.split("#");
        for (String pattern : patterns_separation) {
          if (pattern.length() > widthInt) {
            validWidth = false;
          }
        }
        if ((widthInt == 10 || widthInt == 20 || widthInt == 40 || widthInt == 80) && (highInt == 10
            || highInt == 20 || highInt == 40 || highInt == 80)) {
          validNumbersWH = true;
        }
        validGameParameters = validHigh && validWidth && validNumbersWH;
      }
    } catch (Exception e) {
      System.out.println("fall valid");

    }
  }

  public static void printParameters(String stateInitial, String width, String high,
      String generations, String speed) {
    System.out.println("poulation = " + "[" + stateInitial + "]");
    System.out.println("windth = " + "[" + width + "]");
    System.out.println("heigth = " + "[" + high + "]");
    System.out.println("generations = " + "[" + generations + "]");
    System.out.println("speed = " + "[" + speed + "]");
  }

  public static int validGenerations(String generations) {
    int generationNumbers = Integer.parseInt(generations);
    if (generationNumbers == 0) {
      int valueMax = Integer.MAX_VALUE;
      generationNumbers += valueMax;
    } else if (generationNumbers < 0) {
      generationNumbers *= -1;
    }
    return generationNumbers;
  }

  public static void validInitialState(String patterns, String width) {

    int length = Integer.parseInt(width);
    char[] initialStateNew = new char[length];
    Random RandomGenerator = new Random();
    int numberRandom;
    if (patterns.equals("rnd")) {
      for (int i = 0; i < initialStateNew.length; i++) {
        numberRandom = RandomGenerator.nextInt(10);
        if (numberRandom == 0) {
          initialStateNew[i] = '#';
        } else if (numberRandom % 2 == 0) {
          initialStateNew[i] = '0';
        } else {
          initialStateNew[i] = '1';
        }
      }
      StringBuilder builderState = new StringBuilder();
      for (char elementArray : initialStateNew) {
        builderState.append(elementArray);
      }
      argumentInPoulation = builderState.toString();
    }
  }

  public static void starGameBoard(int rows, int columns, int[][] gameBoard, char[] patters,
      int width, int high) {
    for (rows = 0; rows < high; rows++) {
      for (columns = 0; columns < width; columns++) {
        gameBoard[rows][columns] = 0;
      }
    }
    int changeLines = 0;
    int controlColumns = 0;
    for (int i = 0; i < argumentInPoulation.length(); i++) {
      if (patters[i] == '0') {
        gameBoard[changeLines][controlColumns] = 0;
      } else if (patters[i] == '1') {
        gameBoard[changeLines][controlColumns] = 1;
      }
      controlColumns++;
      if (patters[i] == '#') {
        changeLines++;
        controlColumns = 0;
      }
    }
  }
}