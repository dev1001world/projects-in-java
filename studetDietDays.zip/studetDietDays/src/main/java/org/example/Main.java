package org.example;

public class Main {
    public static void main(String[] args) {
        // 3 4 5 7 3 6 5 3 4 3 10 10 3 4 8 1 1

        int studentNumber = Integer.parseInt(args[0]);
        int numberDays;
        int[] studentDiet;
        int initDietPos = 0;
        int endDietPos = 0;

        for (int i = 0; i < studentNumber; i++) {
            initDietPos = endDietPos + 1;
            numberDays = Integer.parseInt(args[initDietPos]);
            endDietPos = initDietPos + numberDays + 1;
            studentDiet = new int[numberDays + 2];
            studentDiet = createDiet(studentDiet, initDietPos, endDietPos, args);
            verifyDiet(studentDiet);
        }
    }
    public static int[] createDiet(int[]studentDiet, int initDietPos, int endDietPos, String[] args){
        int studentDietPos = 0;
        for (int i = initDietPos; i <= endDietPos; i++) {
            studentDiet[studentDietPos] = Integer.parseInt(args[i]);
            studentDietPos++;
        }
        return studentDiet;
    }
    public static void verifyDiet(int[] studentDiet){
        int proteinToConsume = studentDiet[1];
        String message = null;
        int leftOvers = 0;
        int studentDietPos= 2;
        boolean validDiet = true;

        while(studentDietPos < studentDiet.length && validDiet){
            if (studentDiet[studentDietPos] + leftOvers >= proteinToConsume) {
                message = "Yes";
                leftOvers = (studentDiet[studentDietPos] + leftOvers) - proteinToConsume;
                studentDietPos++;
            }else{
                message = "No " +( studentDietPos -1);
                validDiet = false;
            }
        }
        System.out.println(message);
    }
}